# 独立午餐仿真

固定种子 20261004，仿真日期 2026-10-04，12:00:00–12:10:00，北京时间。36种菜品、42碗；601个逐秒快照、570条事件。起始4人，进店8人、离店2人，最高12人，结束10人。

仅用于厨房环形页面和三维餐厅展示。文件独立保存，不导入任何经营数据库、不参与预测和画像、不读取旧历史数据。

- `manifest.json`：时间范围、种子和版本。
- `events.json`：进店、离店、取菜、补菜事件。
- `snapshots.json`：0–600秒完整快照；每碗克数、状态及客流。
- `validation.json`：守恒、覆盖范围、确定性与SHA256验证结果。
- `playback-verification.json`：完整十分钟原速循环验证，完成后写入。

生成：`node scripts/generate-lunch-demo.mjs`（在 red-koala 根目录）。校验并更新报告：`node scripts/validate-lunch-demo.mjs`。完整原速验收：`python3 scripts/verify-lunch-replay.py`（会重新开始演示，运行约十分钟）。

后端：`GET /api/demo/lunch/state`。控制：`POST /api/demo/lunch/control`，JSON `{"action":"pause"}` / `resume` / `restart`。控制接口验证来源。首次请求创建共享时钟，刷新不会重置；同一后端实例内所有页面共享。重启后端重新开始，不用于跨多实例部署。

状态保留菜品克数，带 `customers`、`playback.second/cycle/paused`、单调递增的响应版本号及仿真/生成双时间。0–599秒用于600秒实时循环；600秒是终点校验快照，状态在循环边界重置为下一轮0秒。

厨房：`http://127.0.0.1:5173/demo/lunch/kitchen`，复用实际环形组件，停用旧保鲜提醒数据源。普通 `/kitchen` 继续使用原项目数据。

三维演示：`http://127.0.0.1:4173/`。配置指向新接口和上述厨房页面；暂停、继续、重播共享。每轮从4位已落座顾客开始，后续进出由目标人数驱动，屏幕同时给出数据集在店数和动画人物数。餐盘食物模型是克数比例分档，不等于实际件数。

数据丢失或读取失败时保留最近有效画面并提示，不启用旧数据或随机生成。
